import 'package:flutter/material.dart';

class CategoriaChip extends StatelessWidget {
  final String texto;

  const CategoriaChip(this.texto);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1E2B35),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(texto),
    );
  }
}