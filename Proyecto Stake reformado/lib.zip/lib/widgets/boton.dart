import 'package:flutter/material.dart';

class BotonAccion extends StatelessWidget {
  final String texto;

  const BotonAccion({required this.texto});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.greenAccent,
        foregroundColor: Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      onPressed: () {},
      child: Text(texto),
    );
  }
}