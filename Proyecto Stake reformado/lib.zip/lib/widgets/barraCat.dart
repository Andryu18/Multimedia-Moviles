import 'package:flutter/material.dart';
import 'categoria.dart';

class BarraCategorias extends StatelessWidget {
  const BarraCategorias({super.key});

  @override
  Widget build(BuildContext context) {
    final categorias = ["Slots", "Casino", "Live", "Sports", "Top"];

    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: categorias.map((c) => CategoriaChip(c)).toList(),
      ),
    );
  }
}