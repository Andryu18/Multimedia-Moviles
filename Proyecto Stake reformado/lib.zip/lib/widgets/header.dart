import 'package:flutter/material.dart';
import 'boton.dart';

class HeaderWidget extends StatelessWidget {
  const HeaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 40, left: 16, right: 16),
      child: Row(
        children: [
          const Text(
            "Stake",
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          const Text("\$0.00"), // Placeholder for SaldoWidget
          const SizedBox(width: 10),
          BotonAccion(texto: "Login"),
        ],
      ),
    );
  }
}