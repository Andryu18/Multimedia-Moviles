import 'package:flutter/material.dart';

// IMPORTS DE TUS WIDGETS
import 'widgets/custom_card.dart';
import 'widgets/barraCat.dart';
import 'widgets/header.dart';
import 'widgets/promo.dart';

void main() {
  runApp(const AplicacionStake());
}

class AplicacionStake extends StatelessWidget {
  const AplicacionStake({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Stake",
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFF0B1217),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.greenAccent,
          brightness: Brightness.dark,
        ),
      ),
      home: const PaginaInicio(),
    );
  }
}

// MODELOS
class Juego {
  final String titulo;
  final String imagen;

  const Juego(this.titulo, this.imagen);
}

class JuegoPago {
  final String nombre;
  final int precio;

  const JuegoPago(this.nombre, this.precio);
}

// PANTALLA PRINCIPAL
class PaginaInicio extends StatelessWidget {
  const PaginaInicio({super.key});

  final List<Juego> juegos = const [
    Juego("Pepsiman", "https://classicgamezone.com/games/covers/ps/pepsiman.webp"),
    Juego("Diep.io", "https://shop.shockwave.com/cdn/shop/collections/diep_Collection.jpg"),
    Juego("Hole.io", "https://image.api.playstation.com/vulcan/ap/rnd/202311/2316/adb72a3412d9762e29c49700fcbbe28aad6f0170bceb0591.jpg"),
    Juego("Real War", "https://www.notebookcheck.org/fileadmin/_processed_/webp/Notebooks/News/_nc5/Real-War-Not-Fake_7-webp-q82-w-h1600.webp"),
  ];

  final List<JuegoPago> listaPagos = const [
    JuegoPago("Baccarat", 75000),
    JuegoPago("MONOPOLY Big Baller", 1500),
  ];

  // ---------------- WIDGETS INTERNOS ----------------

  Widget carrusel(List<Juego> lista) {
    return SizedBox(
      height: 150,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: lista.length,
        itemBuilder: (context, i) {
          return SizedBox(
            width: 120,
            child: TarjetaJuego(
              titulo: lista[i].titulo,
              imagen: lista[i].imagen,
            ),
          );
        },
      ),
    );
  }

  Widget tituloSeccion(String texto) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Text(
        texto,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget listaPagosWidget() {
    return Column(
      children: listaPagos.map((j) {
        return ListTile(
          title: Text(j.nombre),
          trailing: Text("\$${j.precio}"),
        );
      }).toList(),
    );
  }

  BottomNavigationBar barraInferior() {
    return BottomNavigationBar(
      items: [
        BottomNavigationBarItem(icon: Icon(Icons.search), label: "Buscar"),
        BottomNavigationBarItem(icon: Icon(Icons.casino), label: "Casino"),
      ],
    );
  }

  // ---------------- BUILD (SCAFFOLD) ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: barraInferior(),
      body: ListView(
        children: [
          // HEADER (de header.dart)
          HeaderWidget(),

          // PROMO (de promo.dart)
          PromoWidget(),

          // CATEGORIAS (de barraCat.dart)
          BarraCategorias(),

          // JUEGOS
          tituloSeccion("Juegos"),
          carrusel(juegos),

          // PAGOS
          tituloSeccion("Pagos"),
          listaPagosWidget(),

          const SizedBox(height: 30),
        ],
      ),
    );
  }
}